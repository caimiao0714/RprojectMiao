define(function (require) {

    require('../coord/geo/geoCreator');

    require('./geo/GeoView');

    require('../action/geoRoam');
});