/**
 * DataZoom component entry
 */
define(function (require) {

    require('./dataRangeContinuous');
    require('./dataRangePiecewise');

});