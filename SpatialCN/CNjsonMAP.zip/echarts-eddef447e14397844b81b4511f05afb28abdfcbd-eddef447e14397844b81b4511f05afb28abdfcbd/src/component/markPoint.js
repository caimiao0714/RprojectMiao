// HINT Markpoint can't be used too much

define(function (require) {

    require('./marker/MarkPointModel');

    require('./marker/MarkPointView');
});