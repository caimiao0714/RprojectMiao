define(function (require) {
    require('./gauge/GaugeSeries');
    require('./gauge/GaugeView');
});